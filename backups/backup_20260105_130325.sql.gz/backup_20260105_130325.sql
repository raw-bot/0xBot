--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: alert_severity_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.alert_severity_enum AS ENUM (
    'INFO',
    'WARNING',
    'CRITICAL'
);


ALTER TYPE public.alert_severity_enum OWNER TO postgres;

--
-- Name: alert_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.alert_type_enum AS ENUM (
    'TRADE',
    'PNL',
    'RISK',
    'ERROR'
);


ALTER TYPE public.alert_type_enum OWNER TO postgres;

--
-- Name: bot_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.bot_status_enum AS ENUM (
    'INACTIVE',
    'ACTIVE',
    'PAUSED',
    'STOPPED'
);


ALTER TYPE public.bot_status_enum OWNER TO postgres;

--
-- Name: model_name_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.model_name_enum AS ENUM (
    'CLAUDE_SONNET',
    'GPT4',
    'DEEPSEEK_V3',
    'GEMINI_PRO'
);


ALTER TYPE public.model_name_enum OWNER TO postgres;

--
-- Name: position_side_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.position_side_enum AS ENUM (
    'LONG',
    'SHORT'
);


ALTER TYPE public.position_side_enum OWNER TO postgres;

--
-- Name: position_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.position_status_enum AS ENUM (
    'OPEN',
    'CLOSED'
);


ALTER TYPE public.position_status_enum OWNER TO postgres;

--
-- Name: trade_side_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.trade_side_enum AS ENUM (
    'BUY',
    'SELL'
);


ALTER TYPE public.trade_side_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alerts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    bot_id uuid,
    type public.alert_type_enum NOT NULL,
    severity public.alert_severity_enum NOT NULL,
    message character varying(1000) NOT NULL,
    read boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.alerts OWNER TO postgres;

--
-- Name: bots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bots (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    model_name character varying(50) NOT NULL,
    capital numeric(20,2) NOT NULL,
    risk_params json NOT NULL,
    status public.bot_status_enum NOT NULL,
    paper_trading boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    initial_capital numeric(20,2) NOT NULL,
    trading_symbols json DEFAULT '["BTC/USDT"]'::json NOT NULL
);


ALTER TABLE public.bots OWNER TO postgres;

--
-- Name: equity_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equity_snapshots (
    id uuid NOT NULL,
    bot_id uuid NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    equity numeric(20,2) NOT NULL,
    cash numeric(20,2) NOT NULL,
    unrealized_pnl numeric(20,2) NOT NULL
);


ALTER TABLE public.equity_snapshots OWNER TO postgres;

--
-- Name: llm_decisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_decisions (
    id uuid NOT NULL,
    bot_id uuid NOT NULL,
    prompt text NOT NULL,
    response text NOT NULL,
    parsed_decisions json NOT NULL,
    tokens_used integer NOT NULL,
    cost numeric(10,6) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.llm_decisions OWNER TO postgres;

--
-- Name: positions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.positions (
    id uuid NOT NULL,
    bot_id uuid NOT NULL,
    symbol character varying(50) NOT NULL,
    side public.position_side_enum NOT NULL,
    quantity numeric(20,8) NOT NULL,
    entry_price numeric(20,2) NOT NULL,
    current_price numeric(20,2) NOT NULL,
    stop_loss numeric(20,2),
    take_profit numeric(20,2),
    status public.position_status_enum NOT NULL,
    opened_at timestamp without time zone NOT NULL,
    closed_at timestamp without time zone,
    leverage numeric(10,2) DEFAULT 10.0 NOT NULL
);


ALTER TABLE public.positions OWNER TO postgres;

--
-- Name: trades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trades (
    id uuid NOT NULL,
    bot_id uuid NOT NULL,
    position_id uuid,
    symbol character varying(50) NOT NULL,
    side public.trade_side_enum NOT NULL,
    quantity numeric(20,8) NOT NULL,
    price numeric(20,2) NOT NULL,
    fees numeric(20,2) NOT NULL,
    realized_pnl numeric(20,2) NOT NULL,
    executed_at timestamp without time zone NOT NULL
);


ALTER TABLE public.trades OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, dropped, status, osm_chunk, creation_time) FROM stdin;
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM stdin;
\.


--
-- Data for Name: chunk_constraint; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM stdin;
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, finalized) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan (mat_hypertable_id, start_ts, end_ts, user_view_definition) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan_step; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan_step (mat_hypertable_id, step_id, status, start_ts, end_ts, type, config) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2025-10-20 06:32:41.440312+00	t
timescaledb_version	2.22.1	f
exported_uuid	43cdb202-67f6-4900-bf1a-04b23ccdbe65	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_config; Owner: postgres
--

COPY _timescaledb_config.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
bffff7aef3d1
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alerts (id, user_id, bot_id, type, severity, message, read, created_at) FROM stdin;
\.


--
-- Data for Name: bots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bots (id, user_id, name, model_name, capital, risk_params, status, paper_trading, created_at, updated_at, initial_capital, trading_symbols) FROM stdin;
a1b2c3d4-e5f6-7890-abcd-ef1234567890	ac4121f8-54aa-4a72-86fa-523d7bfa8a4f	0xBot v2	deepseek-chat	10000.00	{"max_position_pct": 0.25, "max_drawdown_pct": 0.20}	ACTIVE	t	2026-01-05 11:57:35.692217	2026-01-05 11:57:35.692217	10000.00	["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]
\.


--
-- Data for Name: equity_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equity_snapshots (id, bot_id, "timestamp", equity, cash, unrealized_pnl) FROM stdin;
\.


--
-- Data for Name: llm_decisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_decisions (id, bot_id, prompt, response, parsed_decisions, tokens_used, cost, "timestamp") FROM stdin;
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.positions (id, bot_id, symbol, side, quantity, entry_price, current_price, stop_loss, take_profit, status, opened_at, closed_at, leverage) FROM stdin;
\.


--
-- Data for Name: trades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trades (id, bot_id, position_id, symbol, side, quantity, price, fees, realized_pnl, executed_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, created_at, updated_at) FROM stdin;
ac575fc1-ed63-4212-9720-2129e8bd445a	user@example.com	$2b$12$jNTkwsOjyJ/0FRstlMyM7u0IQHC4V8OFt/5XtgE8S2uY9keDf5BBK	2025-10-21 15:15:55.294752	2025-10-21 15:15:55.294757
ac4121f8-54aa-4a72-86fa-523d7bfa8a4f	dev@test.com	not_used_in_dev	2025-10-24 21:10:17.853496	2025-10-24 21:10:17.853502
94930672-f85a-4dfa-a8f0-2f74e252963e	test@example.com	$2b$12$tRuR/Rl.M.GsnRXHfTC48e.HQd6brlP1eWnXnne/0.7ZDfcnW5bMi	2025-10-25 19:48:06.829856	2025-10-25 19:48:06.829861
51c6ef3c-c1b0-472a-92d1-b58d1868f570	test1761421740@example.com	$2b$12$CeCtsUyDtkbn5Zsl33sWAuJn32tb4l4jCc8TxGPff.kYjLslv3mJy	2025-10-25 19:49:00.629404	2025-10-25 19:49:00.629408
86985b7a-5e92-474d-93c6-e49f91e4dda7	demo@nof1.com	$2b$12$e5Gup9Ro80aji5DyfnlhkuI1FMtLHkPd1E.z0oZIeI8i1xumR.z7W	2025-10-25 19:55:38.283126	2025-10-25 19:55:38.283131
\.


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_constraint_name; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_constraint_name', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, false);


--
-- Name: continuous_agg_migrate_plan_step_step_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.continuous_agg_migrate_plan_step_step_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 1, false);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, false);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 1, false);


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_config; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_config.bgw_job_id_seq', 1000, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: bots bots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bots
    ADD CONSTRAINT bots_pkey PRIMARY KEY (id);


--
-- Name: equity_snapshots equity_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equity_snapshots
    ADD CONSTRAINT equity_snapshots_pkey PRIMARY KEY (id);


--
-- Name: llm_decisions llm_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_decisions
    ADD CONSTRAINT llm_decisions_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: trades trades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_alerts_bot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_alerts_bot_id ON public.alerts USING btree (bot_id);


--
-- Name: ix_alerts_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_alerts_created_at ON public.alerts USING btree (created_at);


--
-- Name: ix_alerts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_alerts_user_id ON public.alerts USING btree (user_id);


--
-- Name: ix_bots_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_bots_user_id ON public.bots USING btree (user_id);


--
-- Name: ix_equity_snapshots_bot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_equity_snapshots_bot_id ON public.equity_snapshots USING btree (bot_id);


--
-- Name: ix_equity_snapshots_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_equity_snapshots_timestamp ON public.equity_snapshots USING btree ("timestamp");


--
-- Name: ix_llm_decisions_bot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_llm_decisions_bot_id ON public.llm_decisions USING btree (bot_id);


--
-- Name: ix_llm_decisions_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_llm_decisions_timestamp ON public.llm_decisions USING btree ("timestamp");


--
-- Name: ix_positions_bot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_positions_bot_id ON public.positions USING btree (bot_id);


--
-- Name: ix_positions_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_positions_symbol ON public.positions USING btree (symbol);


--
-- Name: ix_trades_bot_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_trades_bot_id ON public.trades USING btree (bot_id);


--
-- Name: ix_trades_executed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_trades_executed_at ON public.trades USING btree (executed_at);


--
-- Name: ix_trades_position_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_trades_position_id ON public.trades USING btree (position_id);


--
-- Name: ix_trades_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_trades_symbol ON public.trades USING btree (symbol);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: alerts alerts_bot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_bot_id_fkey FOREIGN KEY (bot_id) REFERENCES public.bots(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bots bots_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bots
    ADD CONSTRAINT bots_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: equity_snapshots equity_snapshots_bot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equity_snapshots
    ADD CONSTRAINT equity_snapshots_bot_id_fkey FOREIGN KEY (bot_id) REFERENCES public.bots(id) ON DELETE CASCADE;


--
-- Name: llm_decisions llm_decisions_bot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_decisions
    ADD CONSTRAINT llm_decisions_bot_id_fkey FOREIGN KEY (bot_id) REFERENCES public.bots(id) ON DELETE CASCADE;


--
-- Name: positions positions_bot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_bot_id_fkey FOREIGN KEY (bot_id) REFERENCES public.bots(id) ON DELETE CASCADE;


--
-- Name: trades trades_bot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_bot_id_fkey FOREIGN KEY (bot_id) REFERENCES public.bots(id) ON DELETE CASCADE;


--
-- Name: trades trades_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_position_id_fkey FOREIGN KEY (position_id) REFERENCES public.positions(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

